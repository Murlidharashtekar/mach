export interface User {
  username: string;
  password: string;
  name: string;
  role: string;
  avatar: string;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
}

export interface MachineData {
  id: string;
  name: string;
  status: 'online' | 'offline' | 'maintenance';
  lastMaintenance: string;
  healthScore: number;
}

export interface PressData {
  date: string;
  count: number;
}

export interface ErrorData {
  date: string;
  count: number;
  type: string;
}

export interface EnergyData {
  date: string;
  consumption: number;
}

export interface PredictionData {
  machineId: string;
  machineName: string;
  failureProbability: number;
  suggestedAction: string;
  timeToFailure: number;
}

export interface MaintenanceRecord {
  id: string;
  machineId: string;
  date: string;
  technician: string;
  description: string;
  duration: number;
}