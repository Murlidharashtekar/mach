import faker from 'faker';
import { format, subDays, subHours, addDays } from 'date-fns';
import { 
  MachineData,
  PressData,
  ErrorData,
  EnergyData,
  PredictionData,
  MaintenanceRecord
} from '../types';

// Set a seed for consistent data
faker.seed(123);

// Generate machine data
export const generateMachines = (count: number): MachineData[] => {
  const machines = [];
  
  for (let i = 0; i < count; i++) {
    machines.push({
      id: faker.datatype.uuid(),
      name: `Machine ${faker.name.firstName().charAt(0)}${i + 1}`,
      status: faker.random.arrayElement(['online', 'online', 'online', 'offline', 'maintenance']) as 'online' | 'offline' | 'maintenance',
      lastMaintenance: format(faker.date.past(0.5), 'yyyy-MM-dd'),
      healthScore: parseFloat(faker.datatype.float({ min: 60, max: 98, precision: 0.1 }).toFixed(1))
    });
  }
  
  return machines;
};

// Generate press count data for the last 30 days
export const generatePressData = (days: number): PressData[] => {
  const data: PressData[] = [];
  
  for (let i = days - 1; i >= 0; i--) {
    const date = format(subDays(new Date(), i), 'yyyy-MM-dd');
    const count = faker.datatype.number({ min: 800, max: 1500 });
    data.push({ date, count });
  }
  
  return data;
};

// Generate error data for the last 30 days
export const generateErrorData = (days: number): ErrorData[] => {
  const data: ErrorData[] = [];
  const errorTypes = ['Minor', 'Major', 'Critical'];
  
  for (let i = days - 1; i >= 0; i--) {
    const date = format(subDays(new Date(), i), 'yyyy-MM-dd');
    
    // Generate fewer errors overall and more minor than critical
    if (faker.datatype.number({ min: 1, max: 10 }) > 3) {
      const errorType = faker.random.arrayElement(errorTypes);
      let min = 0, max = 5;
      
      if (errorType === 'Minor') {
        min = 1;
        max = 8;
      } else if (errorType === 'Major') {
        min = 0;
        max = 4;
      } else {
        min = 0;
        max = 2;
      }
      
      const count = faker.datatype.number({ min, max });
      
      if (count > 0) {
        data.push({ date, count, type: errorType });
      }
    }
  }
  
  return data;
};

// Generate energy consumption data for the last 30 days
export const generateEnergyData = (days: number): EnergyData[] => {
  const data: EnergyData[] = [];
  
  for (let i = days - 1; i >= 0; i--) {
    const date = format(subDays(new Date(), i), 'yyyy-MM-dd');
    const consumption = parseFloat(faker.datatype.float({ min: 350, max: 600, precision: 0.1 }).toFixed(1));
    data.push({ date, consumption });
  }
  
  return data;
};

// Generate failure predictions
export const generatePredictions = (machines: MachineData[]): PredictionData[] => {
  return machines.map(machine => {
    const healthScore = machine.healthScore;
    let failureProbability: number;
    let suggestedAction: string;
    let timeToFailure: number;
    
    if (healthScore < 70) {
      failureProbability = parseFloat(faker.datatype.float({ min: 75, max: 95, precision: 0.1 }).toFixed(1));
      suggestedAction = 'Immediate maintenance required';
      timeToFailure = faker.datatype.number({ min: 1, max: 24 });
    } else if (healthScore < 80) {
      failureProbability = parseFloat(faker.datatype.float({ min: 40, max: 70, precision: 0.1 }).toFixed(1));
      suggestedAction = 'Schedule maintenance soon';
      timeToFailure = faker.datatype.number({ min: 24, max: 72 });
    } else if (healthScore < 90) {
      failureProbability = parseFloat(faker.datatype.float({ min: 15, max: 35, precision: 0.1 }).toFixed(1));
      suggestedAction = 'Monitor closely';
      timeToFailure = faker.datatype.number({ min: 72, max: 168 });
    } else {
      failureProbability = parseFloat(faker.datatype.float({ min: 1, max: 10, precision: 0.1 }).toFixed(1));
      suggestedAction = 'No action needed';
      timeToFailure = faker.datatype.number({ min: 168, max: 336 });
    }
    
    return {
      machineId: machine.id,
      machineName: machine.name,
      failureProbability,
      suggestedAction,
      timeToFailure
    };
  });
};

// Generate maintenance records
export const generateMaintenanceRecords = (machines: MachineData[], count: number): MaintenanceRecord[] => {
  const records: MaintenanceRecord[] = [];
  const technicians = ['John Smith', 'Maria Garcia', 'Alex Johnson', 'Sarah Lee', 'David Kim'];
  
  for (let i = 0; i < count; i++) {
    const machine = faker.random.arrayElement(machines);
    records.push({
      id: faker.datatype.uuid(),
      machineId: machine.id,
      date: format(faker.date.past(0.3), 'yyyy-MM-dd'),
      technician: faker.random.arrayElement(technicians),
      description: faker.random.arrayElement([
        'Routine maintenance',
        'Oil change',
        'Belt replacement',
        'Sensor calibration',
        'Component failure repair',
        'Software update',
        'Cleaning'
      ]),
      duration: faker.datatype.number({ min: 30, max: 240 })
    });
  }
  
  return records;
};

// Export a function to initialize all mock data
export const initializeMockData = () => {
  const machines = generateMachines(8);
  const pressData = generatePressData(30);
  const errorData = generateErrorData(30);
  const energyData = generateEnergyData(30);
  const predictions = generatePredictions(machines);
  const maintenanceRecords = generateMaintenanceRecords(machines, 25);
  
  return {
    machines,
    pressData,
    errorData,
    energyData,
    predictions,
    maintenanceRecords
  };
};

// Simulate ML prediction based on input data
export const predictMachineFailure = (
  pressCount: number, 
  errorRate: number, 
  energyConsumption: number
): {
  probability: number;
  timeToFailure: number;
  confidence: number;
  suggestedAction: string;
} => {
  // This is a very simplified mock of a machine learning prediction
  // In a real scenario, this would use an actual ML model
  
  // Convert inputs to standardized "features"
  const pressNormalized = Math.min(Math.max((pressCount - 800) / 700, 0), 1);
  const errorNormalized = Math.min(Math.max(errorRate / 10, 0), 1);
  const energyNormalized = Math.min(Math.max((energyConsumption - 350) / 250, 0), 1);
  
  // Simple weighted "model"
  const weightedSum = (pressNormalized * 0.3) + (errorNormalized * 0.5) + (energyNormalized * 0.2);
  
  // Apply sigmoid-like function to get probability
  const probability = Math.min(Math.max(weightedSum * 100, 1), 99);
  
  // Calculate mock time to failure based on probability
  const timeToFailure = probability > 70 
    ? faker.datatype.number({ min: 1, max: 24 })
    : probability > 40
      ? faker.datatype.number({ min: 24, max: 72 })
      : probability > 20
        ? faker.datatype.number({ min: 72, max: 168 })
        : faker.datatype.number({ min: 168, max: 336 });
  
  // Mock confidence score
  const confidence = 100 - (Math.abs(50 - probability) / 2);
  
  // Determine suggested action
  let suggestedAction = '';
  if (probability > 70) {
    suggestedAction = 'Immediate maintenance required';
  } else if (probability > 40) {
    suggestedAction = 'Schedule maintenance soon';
  } else if (probability > 20) {
    suggestedAction = 'Monitor closely';
  } else {
    suggestedAction = 'No action needed';
  }
  
  return {
    probability: parseFloat(probability.toFixed(1)),
    timeToFailure,
    confidence: parseFloat(confidence.toFixed(1)),
    suggestedAction
  };
};