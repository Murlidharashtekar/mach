import React, { useState } from 'react';
import Layout from '../components/layout/Layout';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import PressCountChart from '../components/charts/PressCountChart';
import ErrorRateChart from '../components/charts/ErrorRateChart';
import EnergyConsumptionChart from '../components/charts/EnergyConsumptionChart';
import { initializeMockData } from '../services/mockData';
import { BarChart3, FileDown, PieChart, RefreshCw } from 'lucide-react';

const Analytics: React.FC = () => {
  const [chartPeriod, setChartPeriod] = useState<'week' | 'month'>('month');
  const [data] = useState(() => initializeMockData());
  
  return (
    <Layout>
      <div className="flex flex-col md:flex-row md:justify-between md:items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold mb-1">Analytics & Reports</h1>
          <p className="text-gray-400">Detailed manufacturing performance analytics</p>
        </div>
        
        <div className="flex items-center space-x-2 mt-4 md:mt-0">
          <Button 
            size="sm" 
            variant="ghost"
            icon={<FileDown size={16} />}
          >
            Export Data
          </Button>
          <Button 
            size="sm"
            variant="ghost"
            icon={<RefreshCw size={16} />}
          >
            Refresh
          </Button>
        </div>
      </div>
      
      <div className="mb-6 flex items-center justify-between">
        <h2 className="text-xl font-semibold flex items-center">
          <BarChart3 className="mr-2" size={20} />
          Performance Metrics
        </h2>
        <div className="flex items-center space-x-2">
          <Button 
            size="sm" 
            variant={chartPeriod === 'week' ? 'primary' : 'ghost'}
            onClick={() => setChartPeriod('week')}
          >
            Last Week
          </Button>
          <Button 
            size="sm"
            variant={chartPeriod === 'month' ? 'primary' : 'ghost'}
            onClick={() => setChartPeriod('month')}
          >
            Last Month
          </Button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 gap-6 mb-8">
        <Card title="Press Counts Per Day">
          <div className="h-80">
            <PressCountChart data={data.pressData} period={chartPeriod} />
          </div>
          <div className="mt-4 border-t border-dark-700 pt-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="p-3 bg-dark-800/50 rounded">
                <h4 className="text-sm text-gray-400 mb-1">Total Presses</h4>
                <p className="text-xl font-semibold">
                  {data.pressData.reduce((sum, item) => sum + item.count, 0).toLocaleString()}
                </p>
              </div>
              <div className="p-3 bg-dark-800/50 rounded">
                <h4 className="text-sm text-gray-400 mb-1">Average / Day</h4>
                <p className="text-xl font-semibold">
                  {Math.round(data.pressData.reduce((sum, item) => sum + item.count, 0) / data.pressData.length).toLocaleString()}
                </p>
              </div>
              <div className="p-3 bg-dark-800/50 rounded">
                <h4 className="text-sm text-gray-400 mb-1">Max Count</h4>
                <p className="text-xl font-semibold">
                  {Math.max(...data.pressData.map(item => item.count)).toLocaleString()}
                </p>
              </div>
              <div className="p-3 bg-dark-800/50 rounded">
                <h4 className="text-sm text-gray-400 mb-1">Min Count</h4>
                <p className="text-xl font-semibold">
                  {Math.min(...data.pressData.map(item => item.count)).toLocaleString()}
                </p>
              </div>
            </div>
          </div>
        </Card>
        
        <Card title="Error Rates">
          <div className="h-80">
            <ErrorRateChart data={data.errorData} period={chartPeriod} />
          </div>
          <div className="mt-4 border-t border-dark-700 pt-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {['Minor', 'Major', 'Critical'].map(type => {
                const typeData = data.errorData.filter(item => item.type === type);
                const totalErrors = typeData.reduce((sum, item) => sum + item.count, 0);
                
                return (
                  <div key={type} className="p-3 bg-dark-800/50 rounded">
                    <h4 className="text-sm text-gray-400 mb-1">{type} Errors</h4>
                    <p className="text-xl font-semibold">{totalErrors}</p>
                    <div className="mt-2 text-xs">
                      <span className={
                        type === 'Minor' ? 'text-primary-400' :
                        type === 'Major' ? 'text-warning-400' :
                        'text-error-400'
                      }>
                        {((totalErrors / data.errorData.reduce((sum, item) => sum + item.count, 0)) * 100).toFixed(1)}% 
                      </span>
                      <span className="text-gray-400 ml-1">of total errors</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </Card>
        
        <Card title="Energy Consumption (kWh)">
          <div className="h-80">
            <EnergyConsumptionChart data={data.energyData} period={chartPeriod} />
          </div>
          <div className="mt-4 border-t border-dark-700 pt-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="p-3 bg-dark-800/50 rounded">
                <h4 className="text-sm text-gray-400 mb-1">Total Energy</h4>
                <p className="text-xl font-semibold">
                  {data.energyData.reduce((sum, item) => sum + item.consumption, 0).toFixed(1)} kWh
                </p>
              </div>
              <div className="p-3 bg-dark-800/50 rounded">
                <h4 className="text-sm text-gray-400 mb-1">Average / Day</h4>
                <p className="text-xl font-semibold">
                  {(data.energyData.reduce((sum, item) => sum + item.consumption, 0) / data.energyData.length).toFixed(1)} kWh
                </p>
              </div>
              <div className="p-3 bg-dark-800/50 rounded">
                <h4 className="text-sm text-gray-400 mb-1">Peak Usage</h4>
                <p className="text-xl font-semibold">
                  {Math.max(...data.energyData.map(item => item.consumption)).toFixed(1)} kWh
                </p>
              </div>
              <div className="p-3 bg-dark-800/50 rounded">
                <h4 className="text-sm text-gray-400 mb-1">Minimum Usage</h4>
                <p className="text-xl font-semibold">
                  {Math.min(...data.energyData.map(item => item.consumption)).toFixed(1)} kWh
                </p>
              </div>
            </div>
          </div>
        </Card>
      </div>
      
      <div className="mb-6">
        <h2 className="text-xl font-semibold flex items-center mb-4">
          <PieChart className="mr-2" size={20} />
          Production Efficiency
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card title="Efficiency Metrics">
            <div className="space-y-4">
              <div>
                <div className="flex justify-between mb-1 text-sm">
                  <span>Overall Equipment Effectiveness</span>
                  <span className="font-medium">87.3%</span>
                </div>
                <div className="w-full bg-dark-700 rounded-full h-2">
                  <div className="bg-primary-500 h-2 rounded-full" style={{ width: '87.3%' }}></div>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between mb-1 text-sm">
                  <span>Machine Availability</span>
                  <span className="font-medium">92.7%</span>
                </div>
                <div className="w-full bg-dark-700 rounded-full h-2">
                  <div className="bg-success-500 h-2 rounded-full" style={{ width: '92.7%' }}></div>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between mb-1 text-sm">
                  <span>Performance Rate</span>
                  <span className="font-medium">89.1%</span>
                </div>
                <div className="w-full bg-dark-700 rounded-full h-2">
                  <div className="bg-warning-500 h-2 rounded-full" style={{ width: '89.1%' }}></div>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between mb-1 text-sm">
                  <span>Quality Rate</span>
                  <span className="font-medium">96.4%</span>
                </div>
                <div className="w-full bg-dark-700 rounded-full h-2">
                  <div className="bg-secondary-500 h-2 rounded-full" style={{ width: '96.4%' }}></div>
                </div>
              </div>
            </div>
          </Card>
          
          <Card title="Maintenance Impact">
            <div className="space-y-4">
              <div className="flex justify-between items-center p-3 bg-dark-800/50 rounded">
                <div>
                  <h4 className="font-medium">Planned Maintenance</h4>
                  <p className="text-sm text-gray-400">Total Hours</p>
                </div>
                <span className="text-2xl font-semibold">142</span>
              </div>
              
              <div className="flex justify-between items-center p-3 bg-dark-800/50 rounded">
                <div>
                  <h4 className="font-medium">Unplanned Downtime</h4>
                  <p className="text-sm text-gray-400">Total Hours</p>
                </div>
                <span className="text-2xl font-semibold text-error-500">38</span>
              </div>
              
              <div className="flex justify-between items-center p-3 bg-dark-800/50 rounded">
                <div>
                  <h4 className="font-medium">MTTR</h4>
                  <p className="text-sm text-gray-400">Mean Time To Repair</p>
                </div>
                <span className="text-2xl font-semibold">1.7h</span>
              </div>
              
              <div className="flex justify-between items-center p-3 bg-dark-800/50 rounded">
                <div>
                  <h4 className="font-medium">MTBF</h4>
                  <p className="text-sm text-gray-400">Mean Time Between Failures</p>
                </div>
                <span className="text-2xl font-semibold">142h</span>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </Layout>
  );
};

export default Analytics;