import React, { useState } from 'react';
import Layout from '../components/layout/Layout';
import PredictionForm from '../components/ml/PredictionForm';
import PredictionResult from '../components/ml/PredictionResult';

const Predictions: React.FC = () => {
  const [predictionResult, setPredictionResult] = useState<{
    probability: number;
    timeToFailure: number;
    confidence: number;
    suggestedAction: string;
  } | null>(null);
  
  return (
    <Layout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold mb-1">Machine Failure Prediction</h1>
        <p className="text-gray-400">Predict potential machine failures based on performance metrics</p>
      </div>
      
      <div className="mb-6">
        <div className="bg-dark-800/50 rounded-lg p-4 border border-dark-700">
          <h3 className="text-lg font-medium mb-2">How It Works</h3>
          <p className="text-gray-300 mb-3">
            Our Machine Learning model uses historical data combined with current machine performance metrics to predict the likelihood of a machine failure.
          </p>
          <div className="space-y-2 text-sm text-gray-400">
            <p>• Enter the current machine performance metrics in the form below</p>
            <p>• The ML model analyzes the data and predicts failure probability</p>
            <p>• Based on the prediction, the system suggests maintenance actions</p>
            <p>• Higher accuracy is achieved with more historical data</p>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <PredictionForm onPredictionGenerated={setPredictionResult} />
        <PredictionResult result={predictionResult} />
      </div>
    </Layout>
  );
};

export default Predictions;