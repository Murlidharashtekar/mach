import React, { useState, useEffect } from 'react';
import { Gauge, Cpu, Zap, BarChart } from 'lucide-react';
import Layout from '../components/layout/Layout';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import PressCountChart from '../components/charts/PressCountChart';
import ErrorRateChart from '../components/charts/ErrorRateChart';
import EnergyConsumptionChart from '../components/charts/EnergyConsumptionChart';
import MachineStatusCard from '../components/dashboard/MachineStatusCard';
import HealthScoreCard from '../components/dashboard/HealthScoreCard';
import MachineFailurePredictionCard from '../components/dashboard/MachineFailurePredictionCard';
import { initializeMockData } from '../services/mockData';

const Dashboard: React.FC = () => {
  const [chartPeriod, setChartPeriod] = useState<'week' | 'month'>('week');
  const [data, setData] = useState(() => initializeMockData());
  
  return (
    <Layout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold mb-1">Manufacturing Dashboard</h1>
        <p className="text-gray-400">Real-time analytics and machine monitoring</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <MachineStatusCard machines={data.machines} />
        <HealthScoreCard machines={data.machines} />
        <MachineFailurePredictionCard predictions={data.predictions} />
      </div>
      
      <div className="mb-6 flex items-center justify-between">
        <h2 className="text-xl font-semibold">Performance Metrics</h2>
        <div className="flex items-center space-x-2">
          <Button 
            size="sm" 
            variant={chartPeriod === 'week' ? 'primary' : 'ghost'}
            onClick={() => setChartPeriod('week')}
          >
            Last Week
          </Button>
          <Button 
            size="sm"
            variant={chartPeriod === 'month' ? 'primary' : 'ghost'}
            onClick={() => setChartPeriod('month')}
          >
            Last Month
          </Button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <Card 
          title="Press Counts" 
          icon={<Gauge size={20} />}
          className="col-span-full lg:col-span-1"
        >
          <PressCountChart data={data.pressData} period={chartPeriod} />
        </Card>
        
        <Card 
          title="Error Rates" 
          icon={<Cpu size={20} />}
          className="col-span-full lg:col-span-1"
        >
          <ErrorRateChart data={data.errorData} period={chartPeriod} />
        </Card>
        
        <Card 
          title="Energy Consumption" 
          icon={<Zap size={20} />}
          className="col-span-full lg:col-span-1"
        >
          <EnergyConsumptionChart data={data.energyData} period={chartPeriod} />
        </Card>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <Card title="Recent Activity" icon={<BarChart size={20} />}>
          <div className="space-y-4">
            {data.maintenanceRecords.slice(0, 4).map(record => (
              <div key={record.id} className="flex items-start p-3 rounded bg-dark-800/50">
                <div className="flex-1">
                  <div className="flex justify-between">
                    <h4 className="font-medium text-sm">Maintenance: {record.description}</h4>
                    <span className="text-xs text-gray-400">{record.date}</span>
                  </div>
                  <p className="text-sm text-gray-400 mt-1">
                    Technician: {record.technician} • Duration: {record.duration} min
                  </p>
                </div>
              </div>
            ))}
          </div>
        </Card>
        
        <Card title="Machine Performance">
          <div className="space-y-4">
            {data.machines.slice(0, 5).map(machine => (
              <div key={machine.id} className="flex justify-between items-center p-3 rounded bg-dark-800/50">
                <div>
                  <h4 className="font-medium">{machine.name}</h4>
                  <p className="text-sm text-gray-400">Last Maintenance: {machine.lastMaintenance}</p>
                </div>
                <div className="text-right">
                  <span className={`font-medium ${
                    machine.healthScore >= 90 ? 'text-success-500' : 
                    machine.healthScore >= 75 ? 'text-warning-400' : 
                    'text-error-500'
                  }`}>
                    {machine.healthScore}%
                  </span>
                  <p className="text-xs text-gray-400">Health Score</p>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </Layout>
  );
};

export default Dashboard;