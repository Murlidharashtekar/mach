import React, { useState } from 'react';
import Layout from '../components/layout/Layout';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import { Database, CheckCircle, XCircle, PenTool as Tool, Clock, RefreshCw, BarChart, Settings as SettingsIcon } from 'lucide-react';
import { initializeMockData } from '../services/mockData';
import { MachineData } from '../types';

const Machines: React.FC = () => {
  const [data] = useState(() => initializeMockData());
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'online':
        return <CheckCircle className="text-success-500" size={18} />;
      case 'offline':
        return <XCircle className="text-error-500" size={18} />;
      case 'maintenance':
        return <Tool className="text-warning-500" size={18} />;
      default:
        return null;
    }
  };
  
  const getHealthColor = (score: number) => {
    if (score >= 90) return 'text-success-500';
    if (score >= 75) return 'text-warning-500';
    return 'text-error-500';
  };
  
  const filteredMachines = data.machines.filter(machine => {
    const matchesSearch = machine.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || machine.status === statusFilter;
    return matchesSearch && matchesStatus;
  });
  
  return (
    <Layout>
      <div className="flex flex-col md:flex-row md:justify-between md:items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold mb-1">Machine Management</h1>
          <p className="text-gray-400">Monitor and manage your manufacturing machines</p>
        </div>
        
        <div className="flex items-center space-x-2 mt-4 md:mt-0">
          <Button 
            size="sm" 
            variant="primary"
            icon={<RefreshCw size={16} />}
          >
            Refresh Data
          </Button>
        </div>
      </div>
      
      <Card className="mb-6">
        <div className="flex flex-col md:flex-row md:justify-between md:items-center space-y-4 md:space-y-0">
          <div className="relative">
            <input
              type="text"
              placeholder="Search machines..."
              className="w-full md:w-64 px-4 py-2 pl-10 bg-dark-800 border border-dark-700 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <svg className="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
          </div>
          
          <div className="flex space-x-2">
            <Button
              size="sm"
              variant={statusFilter === 'all' ? 'primary' : 'ghost'}
              onClick={() => setStatusFilter('all')}
            >
              All
            </Button>
            <Button
              size="sm"
              variant={statusFilter === 'online' ? 'success' : 'ghost'}
              onClick={() => setStatusFilter('online')}
              icon={<CheckCircle size={16} />}
            >
              Online
            </Button>
            <Button
              size="sm"
              variant={statusFilter === 'offline' ? 'error' : 'ghost'}
              onClick={() => setStatusFilter('offline')}
              icon={<XCircle size={16} />}
            >
              Offline
            </Button>
            <Button
              size="sm"
              variant={statusFilter === 'maintenance' ? 'warning' : 'ghost'}
              onClick={() => setStatusFilter('maintenance')}
              icon={<Tool size={16} />}
            >
              Maintenance
            </Button>
          </div>
        </div>
      </Card>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
        {filteredMachines.map((machine) => (
          <MachineCard key={machine.id} machine={machine} />
        ))}
      </div>
    </Layout>
  );
};

const MachineCard: React.FC<{ machine: MachineData }> = ({ machine }) => {
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'online':
        return <CheckCircle className="text-success-500" size={18} />;
      case 'offline':
        return <XCircle className="text-error-500" size={18} />;
      case 'maintenance':
        return <Tool className="text-warning-500" size={18} />;
      default:
        return null;
    }
  };
  
  const getStatusText = (status: string) => {
    switch (status) {
      case 'online':
        return 'Online';
      case 'offline':
        return 'Offline';
      case 'maintenance':
        return 'Maintenance';
      default:
        return status;
    }
  };
  
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online':
        return 'bg-success-500/20 text-success-500';
      case 'offline':
        return 'bg-error-500/20 text-error-500';
      case 'maintenance':
        return 'bg-warning-500/20 text-warning-500';
      default:
        return 'bg-gray-500/20 text-gray-500';
    }
  };
  
  const getHealthColor = (score: number) => {
    if (score >= 90) return 'text-success-500';
    if (score >= 75) return 'text-warning-500';
    return 'text-error-500';
  };
  
  return (
    <div className="bg-dark-800 border border-dark-700 rounded-lg overflow-hidden shadow-lg transition-all duration-200 hover:shadow-xl">
      <div className="px-4 py-3 border-b border-dark-700 flex items-center justify-between">
        <h3 className="font-medium text-lg flex items-center">
          <Database size={18} className="mr-2 text-primary-500" />
          {machine.name}
        </h3>
        <span className={`px-2 py-1 rounded text-xs font-medium inline-flex items-center ${getStatusColor(machine.status)}`}>
          {getStatusIcon(machine.status)}
          <span className="ml-1">{getStatusText(machine.status)}</span>
        </span>
      </div>
      
      <div className="p-4">
        <div className="mb-4">
          <div className="flex justify-between items-center mb-1">
            <span className="text-sm text-gray-400">Health Score</span>
            <span className={`font-medium ${getHealthColor(machine.healthScore)}`}>
              {machine.healthScore}%
            </span>
          </div>
          <div className="w-full bg-dark-700 rounded-full h-2">
            <div 
              className={`h-2 rounded-full ${
                machine.healthScore >= 90 ? 'bg-success-500' : 
                machine.healthScore >= 75 ? 'bg-warning-500' : 
                'bg-error-500'
              }`} 
              style={{ width: `${machine.healthScore}%` }}
            ></div>
          </div>
        </div>
        
        <div className="space-y-2">
          <div className="flex justify-between px-2 py-1.5 bg-dark-700/50 rounded">
            <span className="text-sm text-gray-400 flex items-center">
              <Clock size={14} className="mr-1.5" />
              Last Maintenance
            </span>
            <span className="font-medium">{machine.lastMaintenance}</span>
          </div>
          
          <div className="flex justify-between px-2 py-1.5 bg-dark-700/50 rounded">
            <span className="text-sm text-gray-400 flex items-center">
              <BarChart size={14} className="mr-1.5" />
              Production Rate
            </span>
            <span className="font-medium">
              {machine.status === 'online' 
                ? `${Math.floor(Math.random() * 80) + 40}/hr` 
                : 'N/A'}
            </span>
          </div>
        </div>
      </div>
      
      <div className="px-4 py-3 bg-dark-900/50 border-t border-dark-700 flex justify-between">
        <Button
          size="sm"
          variant="ghost"
          icon={<BarChart size={16} />}
        >
          Details
        </Button>
        <Button
          size="sm"
          variant="ghost"
          icon={<SettingsIcon size={16} />}
        >
          Settings
        </Button>
      </div>
    </div>
  );
};

export default Machines;