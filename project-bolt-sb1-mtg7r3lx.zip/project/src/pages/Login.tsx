import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Power, User, Lock } from 'lucide-react';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';

const Login: React.FC = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  const { login } = useAuth();
  const navigate = useNavigate();
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!username || !password) {
      setError('Please enter both username and password.');
      return;
    }
    
    setIsLoading(true);
    setError('');
    
    try {
      const success = await login(username, password);
      
      if (success) {
        navigate('/dashboard');
      } else {
        setError('Invalid username or password.');
      }
    } catch (err) {
      setError('An error occurred during login. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <div className="min-h-screen flex items-center justify-center bg-dark-950 p-4">
      <div className="max-w-md w-full">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <Power className="h-12 w-12 text-primary-500" />
          </div>
          <h1 className="text-3xl font-bold text-white">Machine Tree Dashboard</h1>
          <p className="text-gray-400 mt-2">Smart Manufacturing Analytics</p>
        </div>
        
        <div className="bg-dark-900 rounded-lg shadow-xl border border-dark-800 overflow-hidden">
          <div className="p-6">
            <h2 className="text-xl font-semibold mb-6 text-gray-200">Sign In</h2>
            
            {error && (
              <div className="mb-4 p-3 bg-error-900/50 border border-error-800 rounded text-error-300 text-sm">
                {error}
              </div>
            )}
            
            <form onSubmit={handleSubmit}>
              <Input
                type="text"
                label="Username"
                placeholder="Enter your username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                icon={<User size={18} className="text-gray-500" />}
                autoComplete="username"
              />
              
              <Input
                type="password"
                label="Password"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                icon={<Lock size={18} className="text-gray-500" />}
                autoComplete="current-password"
              />
              
              <div className="mt-6">
                <Button
                  type="submit"
                  variant="primary"
                  fullWidth
                  isLoading={isLoading}
                >
                  Sign In
                </Button>
              </div>
            </form>
            
            <div className="mt-4 text-center text-sm text-gray-500">
              <p>Demo credentials: username: <span className="text-gray-300">admin</span>, password: <span className="text-gray-300">1234</span></p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;