import React from 'react';
import { AlertOctagon } from 'lucide-react';
import Card from '../ui/Card';
import { PredictionData } from '../../types';

interface MachineFailurePredictionCardProps {
  predictions: PredictionData[];
}

const MachineFailurePredictionCard: React.FC<MachineFailurePredictionCardProps> = ({ 
  predictions 
}) => {
  // Sort predictions by failure probability (highest first)
  const sortedPredictions = [...predictions]
    .sort((a, b) => b.failureProbability - a.failureProbability)
    .slice(0, 3);
  
  const getPriorityLevel = (probability: number) => {
    if (probability >= 70) return { level: 'High', color: 'text-error-500' };
    if (probability >= 40) return { level: 'Medium', color: 'text-warning-500' };
    return { level: 'Low', color: 'text-success-500' };
  };
  
  const getTimeToFailure = (hours: number) => {
    if (hours < 24) return `${hours} ${hours === 1 ? 'hour' : 'hours'}`;
    const days = Math.floor(hours / 24);
    return `${days} ${days === 1 ? 'day' : 'days'}`;
  };
  
  return (
    <Card
      title="Failure Predictions"
      icon={<AlertOctagon size={20} />}
      variant="warning"
      className="h-full"
    >
      {sortedPredictions.length > 0 ? (
        <div className="space-y-3">
          {sortedPredictions.map(prediction => {
            const priority = getPriorityLevel(prediction.failureProbability);
            
            return (
              <div 
                key={prediction.machineId} 
                className="p-3 rounded bg-dark-800/70 border-l-4 border-warning-600"
              >
                <div className="flex justify-between mb-1">
                  <h4 className="font-medium">{prediction.machineName}</h4>
                  <span className={`${priority.color} font-bold`}>
                    {prediction.failureProbability}%
                  </span>
                </div>
                
                <p className="text-sm text-gray-400 mb-2">
                  Est. failure in: <span className="text-white">{getTimeToFailure(prediction.timeToFailure)}</span>
                </p>
                
                <div className="flex justify-between items-center text-sm">
                  <span className="text-gray-400">Priority:</span>
                  <span className={`font-medium ${priority.color}`}>{priority.level}</span>
                </div>
              </div>
            );
          })}
          
          <div className="pt-2 text-sm text-center">
            <a href="/predictions" className="text-primary-400 hover:text-primary-300 transition-colors">
              View all predictions →
            </a>
          </div>
        </div>
      ) : (
        <div className="text-center py-6 text-gray-400">
          <p>No predictions available</p>
        </div>
      )}
    </Card>
  );
};

export default MachineFailurePredictionCard;