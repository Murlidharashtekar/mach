import React from 'react';
import { Server, AlertCircle, CheckCircle, PenTool as Tool } from 'lucide-react';
import Card from '../ui/Card';
import { MachineData } from '../../types';

interface MachineStatusCardProps {
  machines: MachineData[];
}

const MachineStatusCard: React.FC<MachineStatusCardProps> = ({ machines }) => {
  const onlineMachines = machines.filter(m => m.status === 'online').length;
  const offlineMachines = machines.filter(m => m.status === 'offline').length;
  const maintenanceMachines = machines.filter(m => m.status === 'maintenance').length;
  
  const statuses = [
    { 
      label: 'Online', 
      count: onlineMachines, 
      icon: <CheckCircle className="text-success-500" size={18} />,
      color: 'text-success-500'
    },
    { 
      label: 'Offline', 
      count: offlineMachines, 
      icon: <AlertCircle className="text-error-500" size={18} />,
      color: 'text-error-500'
    },
    { 
      label: 'Maintenance', 
      count: maintenanceMachines, 
      icon: <Tool className="text-warning-500" size={18} />,
      color: 'text-warning-500'
    }
  ];
  
  return (
    <Card
      title="Machine Status"
      icon={<Server size={20} />}
      className="h-full"
    >
      <div className="flex flex-col space-y-2">
        {statuses.map((status) => (
          <div key={status.label} className="flex items-center justify-between p-2 rounded bg-dark-800/50">
            <div className="flex items-center">
              {status.icon}
              <span className="ml-2">{status.label}</span>
            </div>
            <span className={`font-semibold text-lg ${status.color}`}>{status.count}</span>
          </div>
        ))}
        
        <div className="mt-2 pt-2 border-t border-dark-700">
          <div className="flex items-center justify-between">
            <span className="text-gray-400">Total Machines</span>
            <span className="font-semibold text-lg">{machines.length}</span>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default MachineStatusCard;