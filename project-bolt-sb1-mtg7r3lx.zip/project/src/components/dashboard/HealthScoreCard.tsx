import React from 'react';
import { Activity } from 'lucide-react';
import Card from '../ui/Card';
import { MachineData } from '../../types';

interface HealthScoreCardProps {
  machines: MachineData[];
}

const HealthScoreCard: React.FC<HealthScoreCardProps> = ({ machines }) => {
  // Calculate average health score
  const avgScore = machines.length > 0
    ? machines.reduce((sum, machine) => sum + machine.healthScore, 0) / machines.length
    : 0;
  
  // Find worst performing machines
  const sortedMachines = [...machines].sort((a, b) => a.healthScore - b.healthScore);
  const worstMachines = sortedMachines.slice(0, 3);
  
  const getScoreColor = (score: number) => {
    if (score >= 90) return 'text-success-500';
    if (score >= 75) return 'text-warning-400';
    return 'text-error-500';
  };
  
  return (
    <Card
      title="Health Scores"
      icon={<Activity size={20} />}
      className="h-full"
    >
      <div className="mb-4 text-center">
        <div className="text-3xl font-bold mb-1">
          <span className={getScoreColor(avgScore)}>{avgScore.toFixed(1)}%</span>
        </div>
        <p className="text-sm text-gray-400">Average Machine Health</p>
      </div>
      
      <div className="border-t border-dark-700 pt-3">
        <h4 className="text-sm font-medium text-gray-400 mb-2">Machines Requiring Attention</h4>
        <div className="space-y-2">
          {worstMachines.map(machine => (
            <div key={machine.id} className="flex items-center justify-between p-2 rounded bg-dark-800/50">
              <span>{machine.name}</span>
              <span className={`font-medium ${getScoreColor(machine.healthScore)}`}>
                {machine.healthScore}%
              </span>
            </div>
          ))}
        </div>
      </div>
    </Card>
  );
};

export default HealthScoreCard;