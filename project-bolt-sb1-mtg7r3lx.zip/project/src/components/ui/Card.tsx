import React, { ReactNode } from 'react';

interface CardProps {
  title?: string;
  icon?: ReactNode;
  children: ReactNode;
  className?: string;
  footer?: ReactNode;
  variant?: 'default' | 'primary' | 'warning' | 'error' | 'success';
}

const Card: React.FC<CardProps> = ({ 
  title, 
  icon, 
  children, 
  className = '', 
  footer,
  variant = 'default'
}) => {
  const variantClasses = {
    default: 'bg-dark-800 border-dark-700',
    primary: 'bg-primary-900/30 border-primary-700/50',
    warning: 'bg-warning-900/30 border-warning-700/50',
    error: 'bg-error-900/30 border-error-700/50',
    success: 'bg-success-900/30 border-success-700/50',
  };

  return (
    <div className={`rounded-lg border shadow-lg overflow-hidden transition-all duration-200 hover:shadow-xl ${variantClasses[variant]} ${className}`}>
      {(title || icon) && (
        <div className="px-4 py-3 border-b border-dark-700 flex items-center justify-between">
          <h3 className="font-medium text-lg flex items-center">
            {icon && <span className="mr-2">{icon}</span>}
            {title}
          </h3>
        </div>
      )}
      <div className="p-4">{children}</div>
      {footer && (
        <div className="px-4 py-3 bg-dark-900/50 border-t border-dark-700">
          {footer}
        </div>
      )}
    </div>
  );
};

export default Card;