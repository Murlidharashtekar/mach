import React from 'react';
import { 
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';
import { Bar } from 'react-chartjs-2';
import { ErrorData } from '../../types';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

interface ErrorRateChartProps {
  data: ErrorData[];
  period?: 'week' | 'month';
}

const ErrorRateChart: React.FC<ErrorRateChartProps> = ({ 
  data,
  period = 'week'
}) => {
  // Filter data based on period
  const filteredData = period === 'week' ? data.slice(-7) : data;
  
  // Process data to show error types
  const dates = [...new Set(filteredData.map(item => item.date))];
  const sortedDates = dates.sort((a, b) => new Date(a).getTime() - new Date(b).getTime());
  
  // Get unique error types
  const errorTypes = [...new Set(filteredData.map(item => item.type))];
  
  // Create datasets for each error type
  const datasets = errorTypes.map(type => {
    const typeColor = 
      type === 'Minor' ? 'rgba(59, 130, 246, 0.7)' : 
      type === 'Major' ? 'rgba(245, 158, 11, 0.7)' : 
      'rgba(239, 68, 68, 0.7)';
    
    const borderColor = 
      type === 'Minor' ? 'rgba(59, 130, 246, 1)' : 
      type === 'Major' ? 'rgba(245, 158, 11, 1)' : 
      'rgba(239, 68, 68, 1)';
    
    return {
      label: `${type} Errors`,
      data: sortedDates.map(date => {
        const match = filteredData.find(item => item.date === date && item.type === type);
        return match ? match.count : 0;
      }),
      backgroundColor: typeColor,
      borderColor: borderColor,
      borderWidth: 1
    };
  });
  
  const chartData = {
    labels: sortedDates.map(date => {
      const dateObj = new Date(date);
      return dateObj.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    }),
    datasets
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      y: {
        beginAtZero: true,
        stacked: true,
        grid: {
          color: 'rgba(75, 85, 99, 0.15)'
        },
        ticks: {
          color: 'rgba(229, 231, 235, 0.8)'
        }
      },
      x: {
        stacked: true,
        grid: {
          display: false
        },
        ticks: {
          color: 'rgba(229, 231, 235, 0.8)'
        }
      }
    },
    plugins: {
      legend: {
        position: 'top' as const,
        labels: {
          color: 'rgba(229, 231, 235, 0.8)',
          font: {
            size: 12
          }
        }
      },
      tooltip: {
        mode: 'index',
        intersect: false,
        titleFont: {
          size: 14
        },
        bodyFont: {
          size: 13
        },
        padding: 10,
        backgroundColor: 'rgba(17, 24, 39, 0.9)',
        borderColor: 'rgba(75, 85, 99, 0.5)',
        borderWidth: 1
      }
    }
  };

  return (
    <div className="h-64">
      <Bar data={chartData} options={options} />
    </div>
  );
};

export default ErrorRateChart;