import React from 'react';
import { NavLink } from 'react-router-dom';
import { LayoutDashboard, BarChart3, Activity, Settings, AlertTriangle, Database, Power, LogOut } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

const Sidebar: React.FC = () => {
  const { authState, logout } = useAuth();
  
  const navItems = [
    { to: '/dashboard', icon: <LayoutDashboard size={20} />, label: 'Dashboard' },
    { to: '/analytics', icon: <BarChart3 size={20} />, label: 'Analytics' },
    { to: '/predictions', icon: <Activity size={20} />, label: 'Predictions' },
    { to: '/machines', icon: <Database size={20} />, label: 'Machines' },
    { to: '/alerts', icon: <AlertTriangle size={20} />, label: 'Alerts' },
    { to: '/settings', icon: <Settings size={20} />, label: 'Settings' },
  ];

  return (
    <aside className="hidden md:flex flex-col w-64 h-screen bg-dark-900 border-r border-dark-700">
      <div className="p-4 border-b border-dark-700">
        <div className="flex items-center">
          <Power className="h-8 w-8 text-primary-500" />
          <span className="ml-2 text-xl font-bold text-white">Machine Tree</span>
        </div>
      </div>
      
      {authState.user && (
        <div className="p-4 border-b border-dark-700">
          <div className="flex items-center">
            <img 
              src={authState.user.avatar} 
              alt={authState.user.name} 
              className="h-10 w-10 rounded-full object-cover"
            />
            <div className="ml-3">
              <p className="text-sm font-medium text-white">{authState.user.name}</p>
              <p className="text-xs text-gray-400">{authState.user.role}</p>
            </div>
          </div>
        </div>
      )}
      
      <nav className="flex-1 px-2 py-4 overflow-y-auto">
        <ul className="space-y-1">
          {navItems.map((item) => (
            <li key={item.to}>
              <NavLink
                to={item.to}
                className={({ isActive }) => `
                  flex items-center px-4 py-2 rounded-md transition-colors
                  ${isActive 
                    ? 'bg-primary-900/50 text-primary-300' 
                    : 'text-gray-300 hover:bg-dark-800 hover:text-white'}
                `}
              >
                <span className="mr-3">{item.icon}</span>
                {item.label}
              </NavLink>
            </li>
          ))}
        </ul>
      </nav>
      
      <div className="p-4 border-t border-dark-700">
        <button
          onClick={logout}
          className="flex w-full items-center px-4 py-2 text-gray-300 hover:bg-dark-800 hover:text-white rounded-md transition-colors"
        >
          <LogOut size={20} className="mr-3" />
          Logout
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;