import React, { useState } from 'react';
import { Menu, Bell, ChevronDown, User, Settings, LogOut, Menu as MenuIcon } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

interface HeaderProps {
  onMenuToggle: () => void;
}

const Header: React.FC<HeaderProps> = ({ onMenuToggle }) => {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const { authState, logout } = useAuth();
  const navigate = useNavigate();
  
  const handleLogout = () => {
    logout();
    navigate('/login');
    setDropdownOpen(false);
  };
  
  return (
    <header className="bg-dark-900 border-b border-dark-700 px-4 py-3 flex items-center justify-between">
      <div className="flex items-center">
        <button 
          onClick={onMenuToggle}
          className="md:hidden mr-4 text-gray-400 hover:text-white"
        >
          <MenuIcon size={24} />
        </button>
        <h1 className="text-xl font-semibold">Machine Tree Dashboard</h1>
      </div>
      
      <div className="flex items-center space-x-4">
        <button className="p-1.5 rounded-full text-gray-400 hover:text-white hover:bg-dark-800">
          <Bell size={20} />
        </button>
        
        <div className="relative">
          <button 
            className="flex items-center space-x-2 text-sm"
            onClick={() => setDropdownOpen(!dropdownOpen)}
          >
            {authState.user && (
              <>
                <img 
                  src={authState.user.avatar} 
                  alt={authState.user.name} 
                  className="h-8 w-8 rounded-full object-cover"
                />
                <span className="hidden md:block">{authState.user.name}</span>
                <ChevronDown size={16} />
              </>
            )}
          </button>
          
          {dropdownOpen && (
            <div className="absolute right-0 mt-2 w-48 bg-dark-800 border border-dark-700 rounded-md shadow-lg py-1 z-10">
              <a 
                href="#" 
                className="block px-4 py-2 text-sm text-gray-300 hover:bg-dark-700 flex items-center"
                onClick={(e) => {
                  e.preventDefault();
                  setDropdownOpen(false);
                  navigate('/profile');
                }}
              >
                <User size={16} className="mr-2" />
                Profile
              </a>
              <a 
                href="#" 
                className="block px-4 py-2 text-sm text-gray-300 hover:bg-dark-700 flex items-center"
                onClick={(e) => {
                  e.preventDefault();
                  setDropdownOpen(false);
                  navigate('/settings');
                }}
              >
                <Settings size={16} className="mr-2" />
                Settings
              </a>
              <div className="border-t border-dark-700 my-1"></div>
              <a 
                href="#" 
                className="block px-4 py-2 text-sm text-gray-300 hover:bg-dark-700 flex items-center"
                onClick={(e) => {
                  e.preventDefault();
                  handleLogout();
                }}
              >
                <LogOut size={16} className="mr-2" />
                Logout
              </a>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;