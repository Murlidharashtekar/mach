import React from 'react';
import { NavLink } from 'react-router-dom';
import { X, LayoutDashboard, BarChart3, Activity, Settings, AlertTriangle, Database, Power } from 'lucide-react';

interface MobileSidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

const MobileSidebar: React.FC<MobileSidebarProps> = ({ isOpen, onClose }) => {
  const navItems = [
    { to: '/dashboard', icon: <LayoutDashboard size={20} />, label: 'Dashboard' },
    { to: '/analytics', icon: <BarChart3 size={20} />, label: 'Analytics' },
    { to: '/predictions', icon: <Activity size={20} />, label: 'Predictions' },
    { to: '/machines', icon: <Database size={20} />, label: 'Machines' },
    { to: '/alerts', icon: <AlertTriangle size={20} />, label: 'Alerts' },
    { to: '/settings', icon: <Settings size={20} />, label: 'Settings' },
  ];

  return (
    <>
      {/* Backdrop */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 md:hidden"
          onClick={onClose}
        ></div>
      )}
      
      {/* Sidebar */}
      <div 
        className={`
          fixed inset-y-0 left-0 w-64 bg-dark-900 border-r border-dark-700 z-50
          transform transition-transform duration-300 ease-in-out md:hidden
          ${isOpen ? 'translate-x-0' : '-translate-x-full'}
        `}
      >
        <div className="p-4 border-b border-dark-700 flex items-center justify-between">
          <div className="flex items-center">
            <Power className="h-6 w-6 text-primary-500" />
            <span className="ml-2 text-xl font-bold">Machine Tree</span>
          </div>
          <button 
            onClick={onClose}
            className="text-gray-400 hover:text-white"
          >
            <X size={24} />
          </button>
        </div>
        
        <nav className="px-2 py-4">
          <ul className="space-y-1">
            {navItems.map((item) => (
              <li key={item.to}>
                <NavLink
                  to={item.to}
                  className={({ isActive }) => `
                    flex items-center px-4 py-2 rounded-md transition-colors
                    ${isActive 
                      ? 'bg-primary-900/50 text-primary-300' 
                      : 'text-gray-300 hover:bg-dark-800 hover:text-white'}
                  `}
                  onClick={onClose}
                >
                  <span className="mr-3">{item.icon}</span>
                  {item.label}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </>
  );
};

export default MobileSidebar;