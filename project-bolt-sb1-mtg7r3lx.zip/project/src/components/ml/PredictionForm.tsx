import React, { useState } from 'react';
import { ArrowRight } from 'lucide-react';
import Card from '../ui/Card';
import Button from '../ui/Button';
import { predictMachineFailure } from '../../services/mockData';

interface PredictionFormProps {
  onPredictionGenerated: (result: {
    probability: number;
    timeToFailure: number;
    confidence: number;
    suggestedAction: string;
  }) => void;
}

const PredictionForm: React.FC<PredictionFormProps> = ({ onPredictionGenerated }) => {
  const [formData, setFormData] = useState({
    pressCount: 1200,
    errorRate: 3,
    energyConsumption: 450
  });
  
  const [isLoading, setIsLoading] = useState(false);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: parseFloat(value)
    });
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const result = predictMachineFailure(
      formData.pressCount,
      formData.errorRate,
      formData.energyConsumption
    );
    
    onPredictionGenerated(result);
    setIsLoading(false);
  };
  
  return (
    <Card title="Machine Failure Prediction">
      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-300 mb-1">
            Daily Press Count
          </label>
          <input
            type="range"
            name="pressCount"
            min="500"
            max="2000"
            step="50"
            value={formData.pressCount}
            onChange={handleChange}
            className="w-full h-2 bg-dark-700 rounded-lg appearance-none cursor-pointer"
          />
          <div className="flex justify-between mt-1 text-sm text-gray-400">
            <span>500</span>
            <span className="text-white font-medium">{formData.pressCount}</span>
            <span>2000</span>
          </div>
        </div>
        
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-300 mb-1">
            Error Rate (per day)
          </label>
          <input
            type="range"
            name="errorRate"
            min="0"
            max="10"
            step="0.5"
            value={formData.errorRate}
            onChange={handleChange}
            className="w-full h-2 bg-dark-700 rounded-lg appearance-none cursor-pointer"
          />
          <div className="flex justify-between mt-1 text-sm text-gray-400">
            <span>0</span>
            <span className="text-white font-medium">{formData.errorRate}</span>
            <span>10</span>
          </div>
        </div>
        
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-300 mb-1">
            Energy Consumption (kWh)
          </label>
          <input
            type="range"
            name="energyConsumption"
            min="300"
            max="700"
            step="10"
            value={formData.energyConsumption}
            onChange={handleChange}
            className="w-full h-2 bg-dark-700 rounded-lg appearance-none cursor-pointer"
          />
          <div className="flex justify-between mt-1 text-sm text-gray-400">
            <span>300</span>
            <span className="text-white font-medium">{formData.energyConsumption}</span>
            <span>700</span>
          </div>
        </div>
        
        <Button
          type="submit"
          variant="primary"
          fullWidth
          isLoading={isLoading}
          icon={<ArrowRight size={16} />}
          iconPosition="right"
        >
          Generate Prediction
        </Button>
      </form>
    </Card>
  );
};

export default PredictionForm;