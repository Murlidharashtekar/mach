import React from 'react';
import { TrendingUp, Clock, Lightbulb, AlertTriangle } from 'lucide-react';
import Card from '../ui/Card';

interface PredictionResultProps {
  result: {
    probability: number;
    timeToFailure: number;
    confidence: number;
    suggestedAction: string;
  } | null;
}

const PredictionResult: React.FC<PredictionResultProps> = ({ result }) => {
  if (!result) {
    return (
      <Card title="Prediction Results">
        <div className="flex flex-col items-center justify-center py-12 text-gray-400">
          <AlertTriangle size={36} className="mb-3 opacity-70" />
          <p>No prediction data available</p>
          <p className="text-sm mt-1">Use the form to generate a prediction</p>
        </div>
      </Card>
    );
  }
  
  const getRiskColor = (probability: number) => {
    if (probability >= 70) return 'text-error-500';
    if (probability >= 40) return 'text-warning-500';
    return 'text-success-500';
  };
  
  const getRiskLevel = (probability: number) => {
    if (probability >= 70) return 'High Risk';
    if (probability >= 40) return 'Medium Risk';
    return 'Low Risk';
  };
  
  const formatTime = (hours: number) => {
    if (hours < 24) return `${hours} hours`;
    const days = Math.floor(hours / 24);
    const remainingHours = hours % 24;
    if (remainingHours === 0) return `${days} days`;
    return `${days} days, ${remainingHours} hours`;
  };
  
  const riskColor = getRiskColor(result.probability);
  
  return (
    <Card 
      title="Prediction Results"
      variant={result.probability >= 70 ? 'error' : result.probability >= 40 ? 'warning' : 'success'}
    >
      <div className="mb-5 flex flex-col items-center">
        <div className="relative mb-2">
          <svg className="w-32 h-32">
            <circle
              className="text-dark-700"
              strokeWidth="8"
              stroke="currentColor"
              fill="transparent"
              r="56"
              cx="64"
              cy="64"
            />
            <circle
              className={riskColor}
              strokeWidth="8"
              strokeDasharray={352}
              strokeDashoffset={352 * (1 - result.probability / 100)}
              strokeLinecap="round"
              stroke="currentColor"
              fill="transparent"
              r="56"
              cx="64"
              cy="64"
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className={`text-3xl font-bold ${riskColor}`}>{result.probability}%</span>
            <span className="text-sm text-gray-400">Failure Probability</span>
          </div>
        </div>
        <div className={`px-3 py-1 rounded-full ${riskColor} bg-opacity-20 mt-1`}>
          {getRiskLevel(result.probability)}
        </div>
      </div>
      
      <div className="space-y-4">
        <div className="flex items-start">
          <Clock className="mt-0.5 mr-3 text-gray-400" size={18} />
          <div>
            <h4 className="font-medium text-sm">Estimated Time to Failure</h4>
            <p className="text-lg">{formatTime(result.timeToFailure)}</p>
          </div>
        </div>
        
        <div className="flex items-start">
          <TrendingUp className="mt-0.5 mr-3 text-gray-400" size={18} />
          <div>
            <h4 className="font-medium text-sm">Prediction Confidence</h4>
            <p className="text-lg">{result.confidence}%</p>
          </div>
        </div>
        
        <div className="flex items-start">
          <Lightbulb className="mt-0.5 mr-3 text-gray-400" size={18} />
          <div>
            <h4 className="font-medium text-sm">Suggested Action</h4>
            <p className="text-lg">{result.suggestedAction}</p>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default PredictionResult;